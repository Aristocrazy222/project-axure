
function showPage(page) {
  document.querySelectorAll(".page").forEach(p => p.style.display = "none");
  const pageElement = document.getElementById(page);
  if (pageElement) {
    pageElement.style.display = "block";
  } else {
    console.error("Страница не найдена: " + page);
    const errorPage = document.getElementById('error404');
    if (errorPage) {
      errorPage.style.display = "block";
    }
  }
}


document.addEventListener('DOMContentLoaded', () => {
  showPage('home');
});

let cartItems = [];

function addToCart(productName, productPrice) {
  cartItems.push({ name: productName, price: productPrice });
  updateCart();
}

function updateCart() {
  const cartList = document.getElementById('cart-items');
  if (!cartList) return;
  cartList.innerHTML = '';
  let total = 0;
  cartItems.forEach(item => {
    total += item.price;
    const li = document.createElement('li');
    li.textContent = `${item.name} - ${item.price}₸`;
    cartList.appendChild(li);
  });
  const totalPriceElement = document.getElementById('total-price');
  if (totalPriceElement) {
    totalPriceElement.textContent = total;
  }
}

function clearCart() {
  cartItems = [];
  updateCart();
}

function showPage(page) {
    document.querySelectorAll(".page").forEach(p => p.style.display = "none");
    const pageElement = document.getElementById(page);
    if (pageElement) {
        pageElement.style.display = "block";
    } else {
        document.getElementById('error404').style.display = "block";
        window.history.pushState({}, "", "#404");
    }
}
